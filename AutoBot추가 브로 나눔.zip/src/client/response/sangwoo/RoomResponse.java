package client.response.sangwoo;

import client.ClientBack;
import model.vo.Data;

public class RoomResponse {

	public RoomResponse(ClientBack clientback, Data data) {
		Object rowData[][] = (Object[][])data.getObject();
	}

}
