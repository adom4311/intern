package client.response.sungjo;

import client.ClientBack;
import model.vo.Data;

public class CreateGroupRoomListResponse {

	public CreateGroupRoomListResponse(ClientBack clientback, Data data) {
		Object rowData[][] = (Object[][])data.getObject();
		
	}

}
