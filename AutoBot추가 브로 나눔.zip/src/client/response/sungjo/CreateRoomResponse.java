package client.response.sungjo;

import java.util.Map;

import client.ClientBack;
import model.vo.Data;

public class CreateRoomResponse {

	public CreateRoomResponse(ClientBack clientback, Data data) {
		Long groupid = (Long)data.getObject();
		
	}

}
