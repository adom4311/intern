package client.response.sungjo;

import client.ClientBack;
import model.vo.Data;

public class FrilistResponse {

	public FrilistResponse(ClientBack clientback, Data data) {
		Object rowData[][] = (Object[][])data.getObject();
	}

}
