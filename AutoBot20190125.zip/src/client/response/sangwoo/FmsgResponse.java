package client.response.sangwoo;

import client.ClientBack;
import model.vo.Data;

public class FmsgResponse {

	public FmsgResponse(ClientBack clientback, Data data) {
		// TODO Auto-generated constructor stub
	}

}
